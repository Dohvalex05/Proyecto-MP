/***************************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// Fichero: Alumnos.h
//
/***************************************************************************/

#ifndef ALUMNOS
#define ALUMNOS

#include <iostream>
#include <string>

using namespace std;

/***************************************************************************/
/***************************************************************************/
// Constantes globales
/***************************************************************************/
/***************************************************************************/

// Porcentajes de ponderación para calcular la nota final

const double PORC_EV_C = 0.1; // 10 %  --> Evaluación contínua
const double PORC_EP_1 = 0.1; // 10 %  --> Examen práctico 1
const double PORC_EP_2 = 0.2; // 20 %  --> Examen práctico 2
const double PORC_EX_T = 0.6; // 60 %  --> Examen teoría

// Constante que marca la exigencia de semejanza entre dos valores reales 
// para que sean considerados iguales --> Dos valores "double" serán iguales 
// si su diferencia -en valor absoluto- es menor que esta constante. 

const double PRECISION_SON_IGUALES_NOTAS = 1e-3; // 0.001

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

class Alumno 
{                   
    
private:                  

	// Datos identificativos del alumno 
	// PRECAUCIÓN:  Se guarda la dirección de memoria donde empiezan las 
	//				cadenas, que se almacenan en el Heap. Por lo tanto 
	//				deberá gestionar adecuadamente estos bloques de memoria. 

	char * DNI;			// DNI
	char * Nombre;		// Nombre 
	char * Apellidos;	// Apellidos (los dos, separados por una coma)


	// Calificaciones del alumno
	// PRE: Todas las notas cumplen  0 <= nota <= 10

	double Nota_EV_C; // Evaluación contínua
	double Nota_EP_1; // Examen práctico 1
	double Nota_EP_2; // Examen práctico 2
	double Nota_EX_T; // Examen teoría

public:                        

	/***********************************************************************/
	/***********************************************************************/
	// Constructores/Destructor y métodos relacionados
	/***********************************************************************/
	/***********************************************************************/

	// Constructor sin argumentos: crea un "Alumno" vacío.
	// (Campos tipo puntero con valor 0 y notas con valor 0.0) 

	Alumno (void); 

	/***********************************************************************/
	// Constructor con argumentos: crea un "Alumno" con datos personales.
	// No es preciso proporcionar el segundo apellido (nulo, por defecto).
	// Las notas se inicializan a 0.0 (Después pueden actualizarse con los 
	// métodos Set() 

	Alumno (const char *el_DNI, const char *el_nombre, 
            const char *el_ap1, const char *el_ap2="");

	/***********************************************************************/
	// Constructor de copia 

	Alumno (const Alumno & otro);

	/***********************************************************************/
	// Destructor de un  dato "Alumno" 

	~Alumno (void);

	/***********************************************************************/
	// Calcula si un dato "Alumno" está vacío

	bool EstaVacio (void) const;



	/***********************************************************************/
	/***********************************************************************/
	// Operadores
	/***********************************************************************/
	/***********************************************************************/

	// Operador de asignacion

	Alumno & operator = (const Alumno & otro);

	// Operadores relacionales. Criterio: nota media ponderada

	bool operator == (const Alumno & otro) const;
	bool operator != (const Alumno & otro) const;
	bool operator > (const Alumno & otro)  const;
	bool operator < (const Alumno & otro)  const;
	bool operator >= (const Alumno & otro) const;
	bool operator <= (const Alumno & otro) const;



	/***********************************************************************/
	/***********************************************************************/
	// Métodos Get() / Set()
	/***********************************************************************/
	/***********************************************************************/

	char * GetDNI (void) const;
	char * GetNombre (void) const;
	char * GetApellidos (void) const;
	double GetNota_EvContinua (void) const;
	double GetNota_ExPractico_1 (void) const;
	double GetNota_ExPractico_2 (void) const;
	double GetNota_ExTeoria (void) const;

	char * GetNombreCompleto (void) const;
	double GetNotaFinal (void) const; 

	void SetDNI (const char * el_DNI);
	void SetNombre (const char * el_Nombre);
	void SetApellidos (const char * los_Apellidos);

	// PRE: 0.0 <= la_nota* <= 10.0 
	void SetNota_EvContinua   (const double la_Nota_EV_C);
	void SetNota_ExPractico_1 (const double la_Nota_EP_1);
	void SetNota_ExPractico_2 (const double la_Nota_EP_2);
	void SetNota_ExTeoria     (const double la_Nota_EX_T);



	/***********************************************************************/
	/***********************************************************************/
	// Operadores E/S
	/***********************************************************************/
	/***********************************************************************/

	friend ostream & operator << (ostream & out, const Alumno & al);
	friend istream & operator >> (istream & in,  Alumno & al);


	/***********************************************************************/
	/***********************************************************************/
	// Otros
	/***********************************************************************/
	/***********************************************************************/

	// Compone un string para mostrar los datos de un dato "Alumno"

	string ToString (void);

	/***********************************************************************/
	/***********************************************************************/

private:

	/***********************************************************************/
	/***********************************************************************/
	// METODOS PRIVADOS
	/***********************************************************************/
	/***********************************************************************/

	// Libera TODA la memoria ocupada por un dato "Alumno"
	void LiberaMemoria (void); 

	// Copia profunda desde "otro".
	// PRE:	"DNI", "Nombre" y "Apellidos" no tienen memoria asignada. 

	void CopiaDatos (const Alumno & otro);

	/***********************************************************************/
	// Liberar la memoria que ocupan las cadenas clásicas "DNI", "Nombre" y 
	// "Apellidos" por separado.

	void LiberaDNI (void);
	void LiberaNombre (void);
	void LiberaApellidos (void);

	/***********************************************************************/
	// Copiar a los campos "DNI", "Nombre" y "Apellidos" desde el 
	// argumento dado. Se reserva la memoria imprescindible.
	// PRE: "DNI", "Nombre" y "Apellidos" no tienen memoria asignada.

	void CopiaDNI (const char * el_DNI);
	void CopiaNombre (const char * el_Nombre);
	void CopiaApellidos (const char * los_Apellidos);

};

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

/***************************************************************************/
/***************************************************************************/
// Función auxiliar (NO ES UN METODO DE LA CLASE)

bool SonIgualesNotas (const double una, const double otra);

/***************************************************************************/
/***************************************************************************/

#endif

