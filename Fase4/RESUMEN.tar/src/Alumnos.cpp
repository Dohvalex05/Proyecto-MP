/***************************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// Fichero: Alumnos.cpp
//
/***************************************************************************/

#include <iostream>
#include <sstream>
#include <cstring>
#include <string>
#include <cmath>

#include "Alumnos.h"

using namespace std;

/***************************************************************************/
/***************************************************************************/
// Constructores / Destructor 
/***************************************************************************/
/***************************************************************************/

// Constructor sin argumentos: crea un "Alumno" vacío 
// (Campos tipo puntero con valor 0 y notas con valor 0.0) 

Alumno :: Alumno (void) : 
	DNI(0), Nombre(0), Apellidos(0), 
	Nota_EV_C(0.0), Nota_EP_1 (0.0), Nota_EP_2 (0.0), Nota_EX_T (0.0)
{
}

/***************************************************************************/
/***************************************************************************/
// Constructor con argumentos: crea un "Alumno" con datos personales.
// No es preciso proporcionar el segundo apellido (nulo, por defecto).
// Las notas se inicializan a 0.0 (Después pueden actualizarse con los 
// métodos Set() 

Alumno :: Alumno (const char * el_DNI, const char *el_nombre, 
	              const char * el_ap1, const char *el_ap2) 
		: Nota_EP_1(0.0), Nota_EP_2(0.0),
		  Nota_EV_C(0.0), Nota_EX_T(0.0)
{
	CopiaDNI (el_DNI);	// Copiar al campo "DNI"
	CopiaNombre (el_nombre); // Copiar al campo "Nombre"

	// Componer una cadena clásica con los dos apellidos (o el primero)

	char * los_apellidos = new char[strlen(el_ap1)+strlen(el_ap2)+2];
	strcpy(los_apellidos, el_ap1);	

	if (strlen(el_ap2)>0) {	
		strcat(los_apellidos, " ");
		strcat(los_apellidos, el_ap2);
	}

	// Copiar al campo "Apellidos"
	CopiaApellidos (los_apellidos);

	delete [] los_apellidos;
}

/***************************************************************************/
/***************************************************************************/
// Constructor de copia 

Alumno:: Alumno (const Alumno & otro)
{
	CopiaDatos (otro);
}

/***************************************************************************/
/***************************************************************************/
// Destructor de un  dato "Alumno" 

Alumno :: ~Alumno (void)
{
	LiberaMemoria();
}

/***************************************************************************/
/***************************************************************************/
// Calcula si un dato "Alumno" está vacío

bool Alumno :: EstaVacio  (void) const
{
	return (!DNI);  // Basta comprobar si el puntero DNI es 0
}

/***************************************************************************/
/***************************************************************************/
// Operadores 
/***************************************************************************/
/***************************************************************************/

// Operador de asignacion

Alumno & Alumno :: operator = (const Alumno & otro)
{
	if (this != &otro) {
		LiberaMemoria ();
		CopiaDatos (otro);
	}
	return (*this);
}

/***************************************************************************/
/***************************************************************************/
// Operadores relacionales. Criterio: nota media ponderada

bool Alumno :: operator == (const Alumno & otro) const
{
	return (SonIgualesNotas(GetNotaFinal(), otro.GetNotaFinal()));
}

bool Alumno :: operator != (const Alumno & otro) const
{
	return (!((*this) == otro));
}

bool Alumno :: operator > (const Alumno & otro)  const
{
	return (GetNotaFinal() > otro.GetNotaFinal());
}

bool Alumno :: operator < (const Alumno & otro)  const
{
	return (!(((*this) > otro)) && !(((*this) == otro)));
}

bool Alumno :: operator >= (const Alumno & otro) const
{
	return (((*this) > otro) || ((*this) == otro));
}

bool Alumno :: operator <= (const Alumno & otro) const
{
	return (((*this) < otro) || ((*this) == otro));
}


/***************************************************************************/
/***************************************************************************/
// Métodos Get() / Set()
/***************************************************************************/
/***************************************************************************/

// Métodos Get() triviales
 
char * Alumno :: GetDNI (void) const
{
	return (DNI);
}
char * Alumno :: GetNombre (void) const
{
	return (Nombre);
}
char * Alumno :: GetApellidos (void) const
{
	return (Apellidos);
}
double Alumno :: GetNota_EvContinua (void) const
{
	return (Nota_EV_C);
}
double Alumno :: GetNota_ExPractico_1 (void) const
{
	return (Nota_EP_1);
}
double Alumno :: GetNota_ExPractico_2 (void) const
{
	return (Nota_EP_2);
}
double Alumno :: GetNota_ExTeoria (void) const
{
	return (Nota_EX_T);
}

// Devuelve el nombre completo en formato: "apellidos, nombre"

char * Alumno :: GetNombreCompleto (void) const
{
	char * nombre_completo = new char[strlen(Apellidos)+strlen(Nombre)+3];
	strcpy(nombre_completo, Apellidos);	
	strcat(nombre_completo, ", ");	
	strcat(nombre_completo, Nombre);	

	return (nombre_completo);
}

// Calcula y devuelve la nota final

double Alumno :: GetNotaFinal (void) const
{
	double nota_P = (Nota_EV_C*PORC_EV_C) + (Nota_EP_1*PORC_EP_1) + 
					(Nota_EP_2*PORC_EP_2);
	double nota_T = (Nota_EX_T*PORC_EX_T);
	
	return (nota_P+nota_T);
} 


// Métodos Set() de los campos "char *": Antes de escribir los valores, 
// liberan la memoria que tuvieran reservada. 

void Alumno :: SetDNI (const char * el_DNI)
{
	LiberaDNI();
	CopiaDNI (el_DNI);
}

void Alumno :: SetNombre (const char * el_Nombre)
{
	LiberaNombre();
	CopiaNombre (el_Nombre);
}

void Alumno :: SetApellidos (const char * los_Apellidos)
{
	LiberaApellidos();
	CopiaApellidos (los_Apellidos);
}


// Métodos Set() de los campos de las calificaciones. 
// PRE: 0.0 <= la_nota* <= 10.0 
void Alumno :: SetNota_EvContinua (const double la_Nota_EV_C)
{
	Nota_EV_C = la_Nota_EV_C;
}
void Alumno :: SetNota_ExPractico_1 (const double la_Nota_EP_1)
{
	Nota_EP_1 = la_Nota_EP_1;
}
void Alumno :: SetNota_ExPractico_2 (const double la_Nota_EP_2)
{
	Nota_EP_2 = la_Nota_EP_2;
}
void Alumno :: SetNota_ExTeoria (const double la_Nota_EX_T)
{
	Nota_EX_T = la_Nota_EX_T;
}


/***************************************************************************/
/***************************************************************************/
// Operadores de E/S
/***************************************************************************/
/***************************************************************************/

// Operador << 

ostream & operator << (ostream & out, const Alumno & al)
{
	if (!al.EstaVacio()) {

		out << al.DNI << endl;

		// Extraer los dos apellidos de al.Apellidos

		string apellido1, apellido2;

		istringstream iss;
	 	iss.str (al.Apellidos); // Asociar "al.Apellidos" con "iss" 
		iss >> apellido1 >> apellido2;

		out << apellido1 << endl;
	
		if (apellido2.length() > 0)
			out << apellido2 << endl;
		else 
			out << "." << endl; // Si no hay segundo apellido, escribir "."

		// Fin de "Extraer los dos apellidos de al.Apellidos"

		out << al.Nombre << endl;
		out << al.Nota_EV_C << endl;
		out << al.Nota_EP_1 << endl;
		out << al.Nota_EP_2 << endl;
		out << al.Nota_EX_T << endl;
	}

	return (out);
}

/***************************************************************************/
// Operador >>

istream & operator >> (istream & in, Alumno & al)
{
	const int MAXCAD = 100;
	char cad [MAXCAD];

	// Leer DNI

	in.getline(cad, MAXCAD); 
	al.SetDNI (cad);


	// Leer apellidos

	char apellido1 [MAXCAD];
	char apellido2 [MAXCAD];

	in.getline(apellido1, MAXCAD);  
	in.getline(apellido2, MAXCAD);

	char * los_apellidos;

	// Si hay segundo apellido (lo leido es distinto de ".")
	
	if (strcmp(apellido2,".")) {  

 		los_apellidos = new char[strlen(apellido1)+strlen(apellido2)+2];
		strcpy(los_apellidos, apellido1);	
		strcat(los_apellidos, " ");
		strcat(los_apellidos, apellido2);

	} 
	else { // No hay segundo apellido

 		los_apellidos = new char[strlen(apellido1)+1];
		strcpy(los_apellidos, apellido1);	
	}

	// Copiar al campo "Apellidos"
	al.SetApellidos (los_apellidos);

	delete [] los_apellidos;


	// Leer Nombre

	in.getline(cad, MAXCAD); 
	al.SetNombre (cad);


	// Leer las notas

	in.getline(cad, MAXCAD); 
	al.SetNota_EvContinua   (atof(cad));

	in.getline(cad, MAXCAD); 
	al.SetNota_ExPractico_1 (atof(cad));

	in.getline(cad, MAXCAD); 
	al.SetNota_ExPractico_2 (atof(cad));

	in.getline(cad, MAXCAD); 
	al.SetNota_ExTeoria     (atof(cad));

	return (in);
}



/***************************************************************************/
/***************************************************************************/
// Otros
/***************************************************************************/
/***************************************************************************/

// Compone un string para mostrar los datos de un dato "Alumno"

string Alumno :: ToString (void)
{
	string str; 

	if (!EstaVacio()) {
		str = str + DNI + " -- " + Apellidos + ", " + Nombre + "\n";
		str = str + "\t" + " EX.P1 = " + to_string(Nota_EP_1) +
			               " EX.P2 = " + to_string(Nota_EP_2) +
			               " EV.C  = " + to_string(Nota_EV_C) +
			               " EX.T  = " + to_string(Nota_EX_T);
	}
	else 
		str = "SIN DATOS";

	return (str); 
}



/***************************************************************************/
/***************************************************************************/
// METODOS PRIVADOS
/***************************************************************************/
/***************************************************************************/

// Libera TODA la memoria ocupada por un dato "Alumno"

void Alumno :: LiberaMemoria (void)
{
	LiberaDNI();
	LiberaNombre();
	LiberaApellidos();
}

/***************************************************************************/
// Copia profunda desde "otro".
// PRE: "DNI", "Nombre" y "Apellidos" no tienen memoria asignada.

void Alumno :: CopiaDatos (const Alumno & otro)
{
	CopiaDNI (otro.DNI);
	CopiaNombre (otro.Nombre);
	CopiaApellidos (otro.Apellidos);
	Nota_EV_C = otro.Nota_EV_C;
	Nota_EP_1 = otro.Nota_EP_1;
	Nota_EP_2 = otro.Nota_EP_2;
	Nota_EX_T = otro.Nota_EX_T;
}

/***************************************************************************/
// Liberar la memoria que ocupan las cadenas clásicas "DNI", "Nombre" y 
// "Apellidos" por separado.

void Alumno :: LiberaDNI (void)
{
	if (DNI) delete [] DNI;
} 

void Alumno :: LiberaNombre (void)
{
	if (Nombre) delete [] Nombre;
} 

void Alumno :: LiberaApellidos (void)
{
	if (Apellidos) delete [] Apellidos;
} 

/***************************************************************************/
// Copiar a los campos "DNI", "Nombre" y "Apellidos" desde el argumento dado. 
// Observe que se reserva la memoria imprescindible.
// PRE: "DNI", "Nombre" y "Apellidos" no tienen memoria asignada.

void Alumno :: CopiaDNI (const char * el_DNI)
{
	DNI = new char [strlen(el_DNI)+1];
	strcpy (DNI, el_DNI);
}

void Alumno :: CopiaNombre (const char * el_Nombre)
{
	Nombre = new char [strlen(el_Nombre)+1];
	strcpy (Nombre, el_Nombre);
}

void Alumno :: CopiaApellidos (const char * los_Apellidos)
{
	Apellidos = new char [strlen(los_Apellidos)+1];
	strcpy (Apellidos, los_Apellidos);
}

/***************************************************************************/
/***************************************************************************/
// Función auxiliar (NO ES UN METODO DE LA CLASE)
// Devuelve TRUE si "una" y "otra" son muy parecidos. El criterio lo marca 
// la constante "PRECISION_SON_IGUALES_NOTAS"

bool SonIgualesNotas (const double una, const double otra)
{
	return (fabs(una-otra) <= PRECISION_SON_IGUALES_NOTAS);
}

/***************************************************************************/
/***************************************************************************/
