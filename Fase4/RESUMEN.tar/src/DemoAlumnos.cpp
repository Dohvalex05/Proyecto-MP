/***************************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// Fichero: DemoAlumnos.cpp
//
/***************************************************************************/

#include <iostream>

#include "Alumnos.h"

using namespace std;


int main (int argc, char ** argv)
{
	Alumno nadie; 
//	cout << nadie << endl; 
	cout << "vacio: " << nadie.ToString() << endl; 
	cout << endl;


	Alumno al1 ("1234F", "Jose", "Martinez","Garcia"); 

	al1.SetNota_ExPractico_1 (9);
	al1.SetNota_ExPractico_2 (8.5);
	al1.SetNota_EvContinua (10);
	al1.SetNota_ExTeoria (8);

//	cout << al1 << endl; 
	cout << "al1 = " << al1.ToString() << endl; 
	cout << endl;


	Alumno al2 ("9999B", "Pepi", "Gomez"); 

//	cout << al2 << endl; 
	cout << "al2 = " << al2.ToString() << endl; 
	cout << endl;


	// Constructor de copia
	Alumno copia_al1 (al1); 

//	cout << copia_al1 << endl; 
	cout << "copia_al1 = " << copia_al1.ToString() << endl; 
	cout << endl;


	// Operador de asignacion

	Alumno asig_al2;
	asig_al2 = al2;
	cout << "asig_al2 = " << asig_al2.ToString() << endl; 
	cout << endl;


	// Lectura

	cout << endl;
	cout << ".........................................." << endl;
	cout << "Prueba de lectura" << endl;
	cout << ".........................................." << endl;
	cout << endl;

	Alumno un_alumno; 
	Alumno mejor_alumno; // Inicialmente las notas son 0 

	int cont = 0;

	while (cin >> un_alumno) {

		cont++;

		cout << "Alumno " << cont << ": " << un_alumno.ToString() 
             << " --> " << un_alumno.GetNotaFinal() << endl; 

		if (un_alumno > mejor_alumno)
			mejor_alumno = un_alumno; 
	}

	cout << endl;
	cout << ".........................................." << endl;
	cout << endl;

	cout << endl;
	cout << "El mejor alumno es: " << mejor_alumno.GetNombreCompleto()  
         << " --> " << mejor_alumno.GetNotaFinal() << endl; 
	cout << endl;

	return (0); 
}
